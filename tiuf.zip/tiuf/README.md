# Miniräknare Projekt - Alex Jonsson

## Beskrivning
Detta är en Windows Forms-applikation som implementerar en miniräknare med utökade funktioner enligt kursens krav för kapitel 5.

## Funktioner

### Grundfunktioner (Krav 1-5)
- ✅ **Layout och namngivning**: Alla komponenter är korrekt namngivna enligt konventioner
- ✅ **Kommenterad kod**: Varje händelse och funktion har omfattande kommentarer
- ✅ **Fyra räkneoperationer**: Addition, subtraktion, multiplikation och division
- ✅ **Färgknappar**: Röd, blå och grön bakgrundsfärg
- ✅ **Jämförelsefunktion**: Kontrollerar om tal1 > tal2 och visar true/false

### Utökade funktioner (Krav 6)
- ✅ **a) Knappfärger**: Bakgrundsfärgen på knappar ändras automatiskt
- ✅ **b) Miniräknarsymbol**: Emoji-symbol i titeln (🔢)
- ✅ **c) Meddelanderutor**: Används för felhantering och information
- ✅ **d) Ytterligare funktioner**: Potens (x^y) och kvadratrot (√x)
- ✅ **e) Slumpfärger och blink**: Slumpmässiga färger och blinkeffekt
- ✅ **f) Decimalprecision**: Inställbart antal decimaler (0-10)

### Bonusffunktioner för A-betyg
- 🌟 **Avancerad felhantering**: Omfattande try-catch med användarmeddelanden
- 🌟 **Rensa-funktion**: Rensar alla fält med bekräftelse
- 🌟 **Info-knapp**: Visar programinformation och funktioner
- 🌟 **Responsiv design**: Professionell layout med konsekvent styling
- 🌟 **Användarvänlighet**: Centrerade texter, lämpliga fontstorlekar och färgkodning

## Teknisk Implementation

### Arkitektur
- **MainForm.cs**: Huvudlogik och event handlers
- **MainForm.Designer.cs**: GUI-layout och komponentkonfiguration
- **Program.cs**: Applikationens startpunkt
- **MiniraknareProjekt.csproj**: Projektinställningar och beroenden

### Säkerhet och Robusthet
- Division med noll-kontroll
- Kvadratrot av negativa tal-kontroll
- Omfattande exception handling
- Input validation för alla beräkningar

### Användarupplevelse
- Intuitiv layout med logisk gruppering
- Färgkodade knappar för olika funktioner
- Tydliga labels och instruktioner
- Responsiv feedback via MessageBox

## Hur man kör projektet

### Förutsättningar
- .NET 6.0 eller senare
- Windows operativsystem
- Visual Studio 2022 eller Visual Studio Code

### Installationsinstruktioner
1. Klona eller ladda ner projektmappen
2. Öppna `MiniraknareProjekt.sln` i Visual Studio
3. Bygg projektet (Build > Build Solution)
4. Kör applikationen (F5 eller Debug > Start Debugging)

### Alternativ: Kommandorad
```bash
cd MiniraknareProjekt
dotnet build
dotnet run
```

## Bedömningskriterier

### E-nivå ✅
Alla fem första punkter är implementerade och fungerar korrekt:
- Layout och namngivning
- Kommenterad kod
- Fyra räkneoperationer
- Färgknappar
- Jämförelsefunktion

### C-nivå ✅
Utöver E-kraven är minst fyra av sex utökade funktioner implementerade:
- Knappfärgsbyte ✅
- Miniräknarsymbol ✅
- Meddelanderutor ✅
- Ytterligare räknefunktioner ✅
- Slump och blinkfärger ✅
- Decimalprecision ✅

### A-nivå ✅
Alla funktioner plus avancerade tillägg:
- Robust felhantering
- Användarvänlig design
- Ytterligare funktionalitet (rensa, info)
- Professionell kodstruktur
- Omfattande dokumentation

## Skapare
**Alex Jonsson** - Cybersecurity Expert & Developer
- GitHub: [CKCHDX](https://github.com/CKCHDX)
- Website: [oscyra.solutions](https://oscyra.solutions/)

Detta projekt demonstrerar expertis inom:
- C# Windows Forms utveckling
- GUI design och användbarhet
- Robust programmeringsmetoder
- Professionell koddokumentation