namespace MiniraknareProjekt
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        // Kontroller för miniräknaren
        private System.Windows.Forms.TextBox txtTal1;
        private System.Windows.Forms.TextBox txtTal2;
        private System.Windows.Forms.Label lblSvar;
        private System.Windows.Forms.Button btnAddition;
        private System.Windows.Forms.Button btnSubtraktion;
        private System.Windows.Forms.Button btnMultiplikation;
        private System.Windows.Forms.Button btnDivision;
        private System.Windows.Forms.Button btnRod;
        private System.Windows.Forms.Button btnBla;
        private System.Windows.Forms.Button btnGron;
        private System.Windows.Forms.Button btnJamfor;
        private System.Windows.Forms.Button btnSlumpFarg;
        private System.Windows.Forms.Button btnBlink;
        private System.Windows.Forms.Button btnPotens;
        private System.Windows.Forms.Button btnKvadratrot;
        private System.Windows.Forms.Button btnRensa;
        private System.Windows.Forms.Button btnInfo;
        private System.Windows.Forms.NumericUpDown numDecimaler;
        private System.Windows.Forms.Label lblDecimaler;
        private System.Windows.Forms.Label lblTitel;
        private System.Windows.Forms.Label lblTal1;
        private System.Windows.Forms.Label lblTal2;
        private System.Windows.Forms.Label lblResultat;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));

            // Skapar alla kontroller för formuläret
            this.txtTal1 = new System.Windows.Forms.TextBox();
            this.txtTal2 = new System.Windows.Forms.TextBox();
            this.lblSvar = new System.Windows.Forms.Label();
            this.btnAddition = new System.Windows.Forms.Button();
            this.btnSubtraktion = new System.Windows.Forms.Button();
            this.btnMultiplikation = new System.Windows.Forms.Button();
            this.btnDivision = new System.Windows.Forms.Button();
            this.btnRod = new System.Windows.Forms.Button();
            this.btnBla = new System.Windows.Forms.Button();
            this.btnGron = new System.Windows.Forms.Button();
            this.btnJamfor = new System.Windows.Forms.Button();
            this.btnSlumpFarg = new System.Windows.Forms.Button();
            this.btnBlink = new System.Windows.Forms.Button();
            this.btnPotens = new System.Windows.Forms.Button();
            this.btnKvadratrot = new System.Windows.Forms.Button();
            this.btnRensa = new System.Windows.Forms.Button();
            this.btnInfo = new System.Windows.Forms.Button();
            this.numDecimaler = new System.Windows.Forms.NumericUpDown();
            this.lblDecimaler = new System.Windows.Forms.Label();
            this.lblTitel = new System.Windows.Forms.Label();
            this.lblTal1 = new System.Windows.Forms.Label();
            this.lblTal2 = new System.Windows.Forms.Label();
            this.lblResultat = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.numDecimaler)).BeginInit();
            this.SuspendLayout();

            // 
            // txtTal1 - Första talets inmatningsruta
            // 
            this.txtTal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTal1.Location = new System.Drawing.Point(120, 80);
            this.txtTal1.Name = "txtTal1";
            this.txtTal1.Size = new System.Drawing.Size(120, 26);
            this.txtTal1.TabIndex = 0;
            this.txtTal1.Text = "0";
            this.txtTal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;

            // 
            // txtTal2 - Andra talets inmatningsruta
            // 
            this.txtTal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtTal2.Location = new System.Drawing.Point(120, 120);
            this.txtTal2.Name = "txtTal2";
            this.txtTal2.Size = new System.Drawing.Size(120, 26);
            this.txtTal2.TabIndex = 1;
            this.txtTal2.Text = "0";
            this.txtTal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;

            // 
            // lblSvar - Etikett som visar beräkningsresultat
            // 
            this.lblSvar.BackColor = System.Drawing.Color.White;
            this.lblSvar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.lblSvar.Location = new System.Drawing.Point(120, 180);
            this.lblSvar.Name = "lblSvar";
            this.lblSvar.Size = new System.Drawing.Size(120, 30);
            this.lblSvar.TabIndex = 2;
            this.lblSvar.Text = "0";
            this.lblSvar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // 
            // btnAddition - Knapp för addition
            // 
            this.btnAddition.BackColor = System.Drawing.Color.LightBlue;
            this.btnAddition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnAddition.Location = new System.Drawing.Point(20, 230);
            this.btnAddition.Name = "btnAddition";
            this.btnAddition.Size = new System.Drawing.Size(60, 40);
            this.btnAddition.TabIndex = 3;
            this.btnAddition.Text = "+";
            this.btnAddition.UseVisualStyleBackColor = false;
            this.btnAddition.Click += new System.EventHandler(this.btnAddition_Click);

            // 
            // btnSubtraktion - Knapp för subtraktion
            // 
            this.btnSubtraktion.BackColor = System.Drawing.Color.LightBlue;
            this.btnSubtraktion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnSubtraktion.Location = new System.Drawing.Point(90, 230);
            this.btnSubtraktion.Name = "btnSubtraktion";
            this.btnSubtraktion.Size = new System.Drawing.Size(60, 40);
            this.btnSubtraktion.TabIndex = 4;
            this.btnSubtraktion.Text = "-";
            this.btnSubtraktion.UseVisualStyleBackColor = false;
            this.btnSubtraktion.Click += new System.EventHandler(this.btnSubtraktion_Click);

            // 
            // btnMultiplikation - Knapp för multiplikation
            // 
            this.btnMultiplikation.BackColor = System.Drawing.Color.LightBlue;
            this.btnMultiplikation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnMultiplikation.Location = new System.Drawing.Point(160, 230);
            this.btnMultiplikation.Name = "btnMultiplikation";
            this.btnMultiplikation.Size = new System.Drawing.Size(60, 40);
            this.btnMultiplikation.TabIndex = 5;
            this.btnMultiplikation.Text = "*";
            this.btnMultiplikation.UseVisualStyleBackColor = false;
            this.btnMultiplikation.Click += new System.EventHandler(this.btnMultiplikation_Click);

            // 
            // btnDivision - Knapp för division
            // 
            this.btnDivision.BackColor = System.Drawing.Color.LightBlue;
            this.btnDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnDivision.Location = new System.Drawing.Point(230, 230);
            this.btnDivision.Name = "btnDivision";
            this.btnDivision.Size = new System.Drawing.Size(60, 40);
            this.btnDivision.TabIndex = 6;
            this.btnDivision.Text = "/";
            this.btnDivision.UseVisualStyleBackColor = false;
            this.btnDivision.Click += new System.EventHandler(this.btnDivision_Click);

            // 
            // btnRod - Knapp för röd bakgrundsfärg
            // 
            this.btnRod.BackColor = System.Drawing.Color.Red;
            this.btnRod.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnRod.ForeColor = System.Drawing.Color.White;
            this.btnRod.Location = new System.Drawing.Point(300, 80);
            this.btnRod.Name = "btnRod";
            this.btnRod.Size = new System.Drawing.Size(80, 30);
            this.btnRod.TabIndex = 7;
            this.btnRod.Text = "Röd";
            this.btnRod.UseVisualStyleBackColor = false;
            this.btnRod.Click += new System.EventHandler(this.btnRod_Click);

            // 
            // btnBla - Knapp för blå bakgrundsfärg
            // 
            this.btnBla.BackColor = System.Drawing.Color.Blue;
            this.btnBla.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnBla.ForeColor = System.Drawing.Color.White;
            this.btnBla.Location = new System.Drawing.Point(300, 120);
            this.btnBla.Name = "btnBla";
            this.btnBla.Size = new System.Drawing.Size(80, 30);
            this.btnBla.TabIndex = 8;
            this.btnBla.Text = "Blå";
            this.btnBla.UseVisualStyleBackColor = false;
            this.btnBla.Click += new System.EventHandler(this.btnBla_Click);

            // 
            // btnGron - Knapp för grön bakgrundsfärg
            // 
            this.btnGron.BackColor = System.Drawing.Color.Green;
            this.btnGron.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnGron.ForeColor = System.Drawing.Color.White;
            this.btnGron.Location = new System.Drawing.Point(300, 160);
            this.btnGron.Name = "btnGron";
            this.btnGron.Size = new System.Drawing.Size(80, 30);
            this.btnGron.TabIndex = 9;
            this.btnGron.Text = "Grön";
            this.btnGron.UseVisualStyleBackColor = false;
            this.btnGron.Click += new System.EventHandler(this.btnGron_Click);

            // 
            // btnJamfor - Knapp för jämförelse (true/false)
            // 
            this.btnJamfor.BackColor = System.Drawing.Color.Orange;
            this.btnJamfor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnJamfor.Location = new System.Drawing.Point(120, 280);
            this.btnJamfor.Name = "btnJamfor";
            this.btnJamfor.Size = new System.Drawing.Size(120, 30);
            this.btnJamfor.TabIndex = 10;
            this.btnJamfor.Text = "Tal1 > Tal2?";
            this.btnJamfor.UseVisualStyleBackColor = false;
            this.btnJamfor.Click += new System.EventHandler(this.btnJamfor_Click);

            // 
            // btnSlumpFarg - Knapp för slumpmässig färg
            // 
            this.btnSlumpFarg.BackColor = System.Drawing.Color.Magenta;
            this.btnSlumpFarg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnSlumpFarg.ForeColor = System.Drawing.Color.White;
            this.btnSlumpFarg.Location = new System.Drawing.Point(300, 200);
            this.btnSlumpFarg.Name = "btnSlumpFarg";
            this.btnSlumpFarg.Size = new System.Drawing.Size(80, 30);
            this.btnSlumpFarg.TabIndex = 11;
            this.btnSlumpFarg.Text = "Slump";
            this.btnSlumpFarg.UseVisualStyleBackColor = false;
            this.btnSlumpFarg.Click += new System.EventHandler(this.btnSlumpFarg_Click);

            // 
            // btnBlink - Knapp för blinkeffekt
            // 
            this.btnBlink.BackColor = System.Drawing.Color.Yellow;
            this.btnBlink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnBlink.Location = new System.Drawing.Point(390, 80);
            this.btnBlink.Name = "btnBlink";
            this.btnBlink.Size = new System.Drawing.Size(80, 30);
            this.btnBlink.TabIndex = 12;
            this.btnBlink.Text = "Starta Blink";
            this.btnBlink.UseVisualStyleBackColor = false;
            this.btnBlink.Click += new System.EventHandler(this.btnBlink_Click);

            // 
            // btnPotens - Knapp för potensberäkning
            // 
            this.btnPotens.BackColor = System.Drawing.Color.LightGreen;
            this.btnPotens.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnPotens.Location = new System.Drawing.Point(300, 230);
            this.btnPotens.Name = "btnPotens";
            this.btnPotens.Size = new System.Drawing.Size(60, 40);
            this.btnPotens.TabIndex = 13;
            this.btnPotens.Text = "x^y";
            this.btnPotens.UseVisualStyleBackColor = false;
            this.btnPotens.Click += new System.EventHandler(this.btnPotens_Click);

            // 
            // btnKvadratrot - Knapp för kvadratrot
            // 
            this.btnKvadratrot.BackColor = System.Drawing.Color.LightGreen;
            this.btnKvadratrot.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnKvadratrot.Location = new System.Drawing.Point(370, 230);
            this.btnKvadratrot.Name = "btnKvadratrot";
            this.btnKvadratrot.Size = new System.Drawing.Size(60, 40);
            this.btnKvadratrot.TabIndex = 14;
            this.btnKvadratrot.Text = "√x";
            this.btnKvadratrot.UseVisualStyleBackColor = false;
            this.btnKvadratrot.Click += new System.EventHandler(this.btnKvadratrot_Click);

            // 
            // btnRensa - Knapp för att rensa alla fält
            // 
            this.btnRensa.BackColor = System.Drawing.Color.LightCoral;
            this.btnRensa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnRensa.Location = new System.Drawing.Point(390, 120);
            this.btnRensa.Name = "btnRensa";
            this.btnRensa.Size = new System.Drawing.Size(80, 30);
            this.btnRensa.TabIndex = 15;
            this.btnRensa.Text = "Rensa";
            this.btnRensa.UseVisualStyleBackColor = false;
            this.btnRensa.Click += new System.EventHandler(this.btnRensa_Click);

            // 
            // btnInfo - Knapp för programinformation
            // 
            this.btnInfo.BackColor = System.Drawing.Color.LightGray;
            this.btnInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnInfo.Location = new System.Drawing.Point(390, 160);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Size = new System.Drawing.Size(80, 30);
            this.btnInfo.TabIndex = 16;
            this.btnInfo.Text = "Info";
            this.btnInfo.UseVisualStyleBackColor = false;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);

            // 
            // numDecimaler - NumericUpDown för decimalprecision
            // 
            this.numDecimaler.Location = new System.Drawing.Point(120, 320);
            this.numDecimaler.Maximum = new decimal(new int[] { 10, 0, 0, 0 });
            this.numDecimaler.Name = "numDecimaler";
            this.numDecimaler.Size = new System.Drawing.Size(60, 20);
            this.numDecimaler.TabIndex = 17;
            this.numDecimaler.Value = new decimal(new int[] { 2, 0, 0, 0 });
            this.numDecimaler.ValueChanged += new System.EventHandler(this.numDecimaler_ValueChanged);

            // 
            // lblDecimaler - Etikett för decimalprecision
            // 
            this.lblDecimaler.AutoSize = true;
            this.lblDecimaler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblDecimaler.Location = new System.Drawing.Point(20, 322);
            this.lblDecimaler.Name = "lblDecimaler";
            this.lblDecimaler.Size = new System.Drawing.Size(94, 17);
            this.lblDecimaler.TabIndex = 18;
            this.lblDecimaler.Text = "Decimaler:";

            // 
            // lblTitel - Programtitel med skaparens namn
            // 
            this.lblTitel.AutoSize = true;
            this.lblTitel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitel.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblTitel.Location = new System.Drawing.Point(120, 20);
            this.lblTitel.Name = "lblTitel";
            this.lblTitel.Size = new System.Drawing.Size(250, 26);
            this.lblTitel.TabIndex = 19;
            this.lblTitel.Text = "🔢 Miniräknare - Alex Jonsson";

            // 
            // lblTal1 - Etikett för första talet
            // 
            this.lblTal1.AutoSize = true;
            this.lblTal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblTal1.Location = new System.Drawing.Point(20, 85);
            this.lblTal1.Name = "lblTal1";
            this.lblTal1.Size = new System.Drawing.Size(89, 17);
            this.lblTal1.TabIndex = 20;
            this.lblTal1.Text = "Första tal:";

            // 
            // lblTal2 - Etikett för andra talet
            // 
            this.lblTal2.AutoSize = true;
            this.lblTal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblTal2.Location = new System.Drawing.Point(20, 125);
            this.lblTal2.Name = "lblTal2";
            this.lblTal2.Size = new System.Drawing.Size(86, 17);
            this.lblTal2.TabIndex = 21;
            this.lblTal2.Text = "Andra tal:";

            // 
            // lblResultat - Etikett för resultat
            // 
            this.lblResultat.AutoSize = true;
            this.lblResultat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblResultat.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblResultat.Location = new System.Drawing.Point(20, 185);
            this.lblResultat.Name = "lblResultat";
            this.lblResultat.Size = new System.Drawing.Size(76, 20);
            this.lblResultat.TabIndex = 22;
            this.lblResultat.Text = "Resultat:";

            // 
            // MainForm - Huvudformulär för miniräknaren
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(490, 360);
            this.Controls.Add(this.lblResultat);
            this.Controls.Add(this.lblTal2);
            this.Controls.Add(this.lblTal1);
            this.Controls.Add(this.lblTitel);
            this.Controls.Add(this.lblDecimaler);
            this.Controls.Add(this.numDecimaler);
            this.Controls.Add(this.btnInfo);
            this.Controls.Add(this.btnRensa);
            this.Controls.Add(this.btnKvadratrot);
            this.Controls.Add(this.btnPotens);
            this.Controls.Add(this.btnBlink);
            this.Controls.Add(this.btnSlumpFarg);
            this.Controls.Add(this.btnJamfor);
            this.Controls.Add(this.btnGron);
            this.Controls.Add(this.btnBla);
            this.Controls.Add(this.btnRod);
            this.Controls.Add(this.btnDivision);
            this.Controls.Add(this.btnMultiplikation);
            this.Controls.Add(this.btnSubtraktion);
            this.Controls.Add(this.btnAddition);
            this.Controls.Add(this.lblSvar);
            this.Controls.Add(this.txtTal2);
            this.Controls.Add(this.txtTal1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Miniräknare";

            ((System.ComponentModel.ISupportInitialize)(this.numDecimaler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}