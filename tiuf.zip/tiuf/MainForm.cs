using System;
using System.Drawing;
using System.Windows.Forms;

namespace MiniraknareProjekt
{
    // miniräknaren
    public partial class MainForm : Form
    {
        // Privata fält
        private Random random = new Random();
        private System.Windows.Forms.Timer blinkTimer;
        private bool isBlinking = false;
        private Color originalBackColor;

        public MainForm()
        {
            InitializeComponent();
            InitializeBlinkTimer();
            originalBackColor = this.BackColor;
        }

        //timer för blinkfunktionen
        private void InitializeBlinkTimer()
        {
            blinkTimer = new System.Windows.Forms.Timer();
            blinkTimer.Interval = 500; // Blinkar var 500ms
            blinkTimer.Tick += BlinkTimer_Tick;
        }

        // Event handler
        private void BlinkTimer_Tick(object sender, EventArgs e)
        {
            if (isBlinking)
            {
                // Växlar mellan slumpmässig färg och originalfärg
                Color randomColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
                this.BackColor = this.BackColor == originalBackColor ? randomColor : originalBackColor;
            }
        }

        // Utför addition av tal1 och tal2
        private void btnAddition_Click(object sender, EventArgs e)
        {
            try
            {
                // Läser in värden från textrutorna
                double tal1 = Convert.ToDouble(txtTal1.Text);
                double tal2 = Convert.ToDouble(txtTal2.Text);

                // Beräknar summan
                double resultat = tal1 + tal2;

                // Visar resultatet med angivet antal decimaler
                lblSvar.Text = FormatResult(resultat);
            }
            catch (Exception ex)
            {
                // Visar felmeddelande om något går fel
                MessageBox.Show("Fel vid addition: " + ex.Message, "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Utför subtraktion av tal1 och tal2
        private void btnSubtraktion_Click(object sender, EventArgs e)
        {
            try
            {
                // Läser in värden från textrutorna
                double tal1 = Convert.ToDouble(txtTal1.Text);
                double tal2 = Convert.ToDouble(txtTal2.Text);

                // Beräknar differensen
                double resultat = tal1 - tal2;

                // Visar resultatet med angivet antal decimaler
                lblSvar.Text = FormatResult(resultat);
            }
            catch (Exception ex)
            {
                // Visar felmeddelande om något går fel
                MessageBox.Show("Fel vid subtraktion: " + ex.Message, "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Utför multiplikation av tal1 och tal2
        private void btnMultiplikation_Click(object sender, EventArgs e)
        {
            try
            {
                // Läser in värden från textrutorna
                double tal1 = Convert.ToDouble(txtTal1.Text);
                double tal2 = Convert.ToDouble(txtTal2.Text);

                // Beräknar produkten
                double resultat = tal1 * tal2;

                // Visar resultatet med angivet antal decimaler
                lblSvar.Text = FormatResult(resultat);
            }
            catch (Exception ex)
            {
                // Visar felmeddelande om något går fel
                MessageBox.Show("Fel vid multiplikation: " + ex.Message, "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Utför division av tal1 och tal2
        private void btnDivision_Click(object sender, EventArgs e)
        {
            try
            {
                // Läser in värden från textrutorna
                double tal1 = Convert.ToDouble(txtTal1.Text);
                double tal2 = Convert.ToDouble(txtTal2.Text);

                // Kontrollerar division med noll
                if (tal2 == 0)
                {
                    MessageBox.Show("Division med noll är inte tillåten!", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Beräknar kvoten
                double resultat = tal1 / tal2;

                // Visar resultatet med angivet antal decimaler
                lblSvar.Text = FormatResult(resultat);
            }
            catch (Exception ex)
            {
                // Visar felmeddelande om något går fel
                MessageBox.Show("Fel vid division: " + ex.Message, "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        // Byter bakgrundsfärg till röd
        private void btnRod_Click(object sender, EventArgs e)
        {
            // Ändrar bakgrundsfärg och uppdaterar originalfärg
            this.BackColor = Color.Red;
            originalBackColor = Color.Red;

            // Ändrar även knappfärger
            ChangeButtonColors(Color.LightCoral);
        }


        // Byter bakgrundsfärg till blå
        private void btnBla_Click(object sender, EventArgs e)
        {
            // Ändrar bakgrundsfärg och uppdaterar originalfärg
            this.BackColor = Color.Blue;
            originalBackColor = Color.Blue;

            // Ändrar även knappfärger
            ChangeButtonColors(Color.LightBlue);
        }

        // Byter bakgrundsfärg till grön
        private void btnGron_Click(object sender, EventArgs e)
        {
            // Ändrar bakgrundsfärg och uppdaterar originalfärg
            this.BackColor = Color.Green;
            originalBackColor = Color.Green;

            // Ändrar även knappfärger
            ChangeButtonColors(Color.LightGreen);
        }

        // Kontrollerar om tal1 är större än tal2
        private void btnJamfor_Click(object sender, EventArgs e)
        {
            try
            {
                // Läser in värden från textrutorna
                double tal1 = Convert.ToDouble(txtTal1.Text);
                double tal2 = Convert.ToDouble(txtTal2.Text);

                // Jämför talen och visar true/false
                bool resultat = tal1 > tal2;
                lblSvar.Text = resultat.ToString();

                // Visar även i meddelanderuta
                string meddelande = tal1 > tal2 ? $"{tal1} är större än {tal2}" : $"{tal1} är inte större än {tal2}";
                MessageBox.Show(meddelande, "Jämförelse", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Visar felmeddelande om något går fel
                MessageBox.Show("Fel vid jämförelse: " + ex.Message, "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Slumpar bakgrundsfärg
        private void btnSlumpFarg_Click(object sender, EventArgs e)
        {
            // Skapar slumpmässig färg
            Color slumpFarg = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));
            this.BackColor = slumpFarg;
            originalBackColor = slumpFarg;

            // Ändrar även knappfärger till en ljusare variant
            Color knappFarg = Color.FromArgb(
                Math.Min(255, slumpFarg.R + 50),
                Math.Min(255, slumpFarg.G + 50),
                Math.Min(255, slumpFarg.B + 50)
            );
            ChangeButtonColors(knappFarg);
        }

        // Startar/stoppar blinkeffekt

        private void btnBlink_Click(object sender, EventArgs e)
        {
            isBlinking = !isBlinking;
            if (isBlinking)
            {
                // Startar blinkeffekt
                blinkTimer.Start();
                btnBlink.Text = "Stoppa Blink";
            }
            else
            {
                // Stoppar blinkeffekt och återställer färg
                blinkTimer.Stop();
                this.BackColor = originalBackColor;
                btnBlink.Text = "Starta Blink";
            }
        }

        // Beräknar potens (tal^tal)

        private void btnPotens_Click(object sender, EventArgs e)
        {
            try
            {
                // Läser in värden från textrutorna
                double tal1 = Convert.ToDouble(txtTal1.Text);
                double tal2 = Convert.ToDouble(txtTal2.Text);

                // Beräknar potens
                double resultat = Math.Pow(tal1, tal2);

                // Visar resultatet
                lblSvar.Text = FormatResult(resultat);
            }
            catch (Exception ex)
            {
                // Visar felmeddelande om något går fel
                MessageBox.Show("Fel vid potensberäkning: " + ex.Message, "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Beräknar kvadratrot av tal1
        private void btnKvadratrot_Click(object sender, EventArgs e)
        {
            try
            {
                // Läser in värde från första textrutan
                double tal1 = Convert.ToDouble(txtTal1.Text);

                // Kontrollerar att talet inte är negativt
                if (tal1 < 0)
                {
                    MessageBox.Show("Kan inte beräkna kvadratrot av negativt tal!", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Beräknar kvadratrot
                double resultat = Math.Sqrt(tal1);

                // Visar resultatet
                lblSvar.Text = FormatResult(resultat);
            }
            catch (Exception ex)
            {
                // Visar felmeddelande om något går fel
                MessageBox.Show("Fel vid kvadratrotsberäkning: " + ex.Message, "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Rensar alla textrutor och resultatet
        private void btnRensa_Click(object sender, EventArgs e)
        {
            // Rensar alla inmatningsfält
            txtTal1.Text = "";
            txtTal2.Text = "";
            lblSvar.Text = "0";

            // Visar bekräftelse
            MessageBox.Show("Alla fält har rensats!", "Rensning", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Ändrar decimalprecision baserat på användarens val
        private void numDecimaler_ValueChanged(object sender, EventArgs e)
        {
            // Uppdaterar aktuellt resultat med ny precision
            if (lblSvar.Text != "0" && double.TryParse(lblSvar.Text, out double currentValue))
            {
                lblSvar.Text = FormatResult(currentValue);
            }
        }

        // Formaterar resultat med angivet antal decimaler
        private string FormatResult(double value)
        {
            int decimaler = (int)numDecimaler.Value;
            return Math.Round(value, decimaler).ToString($"F{decimaler}");
        }

        // Ändrar bakgrundsfärg på alla knappar
        private void ChangeButtonColors(Color color)
        {
            foreach (Control control in this.Controls)
            {
                if (control is Button button && !button.Name.Contains("Farg"))
                {
                    button.BackColor = color;
                }
            }
        }

        // Visar information om programmet
        private void btnInfo_Click(object sender, EventArgs e)
        {
            string info = "Miniräknare v1.0\n" +
                         "Skapad av: Alex Jonsson\n\n" +
                         "Funktioner:\n" +
                         "• Grundläggande räkneoperationer\n" +
                         "• Färgbyte av bakgrund och knappar\n" +
                         "• Slumpmässiga färger och blinkeffekt\n" +
                         "• Potens- och kvadratrotsberäkning\n" +
                         "• Inställbar decimalprecision\n" +
                         "• Jämförelsefunktion";

            MessageBox.Show(info, "Om Miniräknare", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}