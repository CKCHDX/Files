using System;
using System.Windows.Forms;

namespace MiniraknareProjekt
{
    // Huvudklass
    static class Program
    {
        // Programmets huvudingångspunkt
        [STAThread]
        static void Main()
        {
            // Aktiverar visuella stilar för Windows Forms
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Skapar och startar huvudformuläret
            Application.Run(new MainForm());
        }
    }
}