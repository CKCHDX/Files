# Instruktioner för C# Miniräknare Projektet

## Hur du använder projektet

### Steg 1: Öppna projektet
1. Öppna Visual Studio 2022
2. Välj "Open a project or solution"
3. Navigera till mappen `MiniraknareProjekt`
4. Öppna filen `MiniraknareProjekt.csproj`

### Steg 2: Bygg projektet
1. Högerklicka på projektet i Solution Explorer
2. Välj "Build" för att kompilera koden
3. Kontrollera att inga fel uppstår i Output-fönstret

### Steg 3: Kör programmet
1. Tryck F5 eller klicka på "Start Debugging"
2. Miniräknaren öppnas i ett nytt fönster

## Funktioner att testa

### Grundfunktioner (för E-betyg)
✅ **Räkneoperationer**: Testa +, -, *, / med olika tal  
✅ **Färgknappar**: Klicka på Röd, Blå, Grön knapparna  
✅ **Jämförelse**: Ange två tal och klicka "Tal1 > Tal2?"  

### Utökade funktioner (för C-betyg)
✅ **Slumpmässig färg**: Klicka "Slump" för att byta färg  
✅ **Blinkeffekt**: Klicka "Starta Blink" för blinkande färger  
✅ **Potens**: Testa x^y funktionen  
✅ **Kvadratrot**: Testa √x funktionen  
✅ **Decimaler**: Ändra antal decimaler med pilknapparna  

### Avancerade funktioner (för A-betyg)
✅ **Felhantering**: Testa division med 0, kvadratrot av negativt tal  
✅ **Rensa**: Klicka "Rensa" för att töma alla fält  
✅ **Info**: Klicka "Info" för programinformation  

## Kodstruktur

### MainForm.cs
- Huvudlogik för alla beräkningar
- Event handlers för knapptryckningar
- Felhantering och validering

### MainForm.Designer.cs
- GUI-layout och komponentdesign
- Knapppositioner och storlekar
- Färger och fonter

### Program.cs
- Applikationens startpunkt
- Windows Forms-initialisering

## Bedömningskriterier

### För E-betyg (Godkänt)
- [x] Layout med korrekta komponentnamn
- [x] Kommenterad kod för alla händelser
- [x] Fyra räkneoperationer fungerar
- [x] Tre färgknappar fungerar
- [x] Jämförelsefunktion (true/false)

### För C-betyg (Väl Godkänt)
- [x] Alla E-krav uppfyllda
- [x] Minst 4 av 6 utökade funktioner:
  - [x] Knappfärger ändras
  - [x] Miniräknarsymbol (🔢)
  - [x] Meddelanderutor
  - [x] Ytterligare räknefunktioner
  - [x] Slump och blinkfärger
  - [x] Decimalprecision

### För A-betyg (Mycket Väl Godkänt)
- [x] Alla C-krav uppfyllda
- [x] Avancerad funktionalitet:
  - [x] Robust felhantering
  - [x] Rensa-funktion
  - [x] Info-knapp
  - [x] Professionell design
  - [x] Excellenta kommentarer

## Tips för utveckling

### Om du vill lägga till fler funktioner:
1. **Nya knappar**: Lägg till i Designer.cs och skapa click-events
2. **Fler operationer**: Implementera i MainForm.cs med felhantering
3. **Design**: Ändra färger och layout i Designer.cs

### Felsökning:
- Kontrollera att alla using-statements finns
- Se till att .NET 6.0 är installerat
- Bygg om projektet vid kompileringsfel

## Inlämning

1. **Kontrollera koden**: Alla händelser kommenterade ✅
2. **Testa alla funktioner**: Inget får krascha ✅
3. **Zippa projektet**: Högerklicka på mappen → Send to → Compressed folder
4. **Byt namn**: Till "Miniräknare_AlexJonsson.zip"
5. **Lämna in**: På Fronter (max 1 MB)

## Kontakt
För frågor om projektet, kontakta Alex Jonsson:
- GitHub: [CKCHDX](https://github.com/CKCHDX)
- Website: [oscyra.solutions](https://oscyra.solutions/)

---
**Lycka till med kursen! 🚀**